document.getElementById("yesButton").addEventListener("click", function() {
    alert("Yay! I knew you'd say yes! 💖\n\nMeet me in Blessed Christian School Feb 14, 4 PM");
});

document.getElementById("noButton").addEventListener("click", function() {
    let noButton = document.getElementById("noButton");

    // Get window size and calculate random position
    let maxX = window.innerWidth - noButton.offsetWidth;
    let maxY = window.innerHeight - noButton.offsetHeight;

    // Generate random position for the "No" button
    let randomX = Math.floor(Math.random() * maxX);
    let randomY = Math.floor(Math.random() * maxY);

    // Move the "No" button
    noButton.style.left = `${randomX}px`;
    noButton.style.top = `${randomY}px`;
});
